<?php

require 'functionUser.php';



require 'layout/navbar.php';

?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=\, initial-scale=1.0">
  <title>Halaman User</title>
  <style>
    h1{
      margin-left: 30px;
    }

    table{
      margin-left: 30px;
      font-family:'Trebuchet MS', 'Lucida Sans Unicode', 'Lucida Grande', 'Lucida Sans', Arial, sans-serif;
    }

  </style>
</head>
<body>
  <h1>Ini Halaman Customer</h1> <br>
  <table border="4" cellpadding="10" cellspacing="1">
        <tr>
            <th>No.</th>
            <th>Nama Produk</th>
            <th>Harga Produk</th>
            <th>Foto Produk</th>
            <th>Stok Produk</th>
            <th>Deskripsi Produk</th>
        </tr>

        <?php
        
        include "koneksi.php";
        $no=1;
        $ambildata = (mysqli_query($conn, "SELECT * FROM produk"));
        while ($tampil = mysqli_fetch_array($ambildata)){
          echo"
            <tr>
              <td>$no</td>
              <td>$tampil[nama_produk]</td>
              <td>$tampil[harga]</td>
              <td>$tampil[foto]</td>
              <td>$tampil[stok]</td>
              <td>$tampil[deskripsi]</td>

            </tr>";
            $no++;
        }
        ?>
    </table>
</body>
</html>
