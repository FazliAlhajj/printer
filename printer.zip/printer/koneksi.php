<?php

$conn = mysqli_connect("localhost", "root", "", "toko_printer");

?>